Project 1
Name: Adarsh Janapareddy; NetID: ajanap2; UIN: 673176117
Name: Piyush Chandra; NetID: pchand30; UIN: 671764133
Name: Chirag Patel; 
Net ID: cpatel48; UIN: 659651337

Contribution:
Adarsh- Merging Datasets (Question 1),Finding Hypotheses Test statistics ( Question 6 and 7), Plots Party Vs Race and Ethinicity, Bonus Question 10, Report
Piyush- Merging two datasets, Plots (Party VS Education, Population, Sex), Question 9 - Conclusions
Chirag- Creating Variables, Exploring dataset for Question 9, Plots (Party Vs Age)

HOW TO RUN:
Make sure "Project_1.ipynb" file is in the same directory as the "demographics_train" and "election_train" data files.
Make Sure the "Fips.xlsx" file is also in the same directory as the above files.
Open Jupyter Notebook and "Run All Cells" of "Project_1.ipynb" file.
Make sure to resolve all dependencies such as downloading libraries plotly, geopandas and pyshp.
The Outputs can be seen with comments.
